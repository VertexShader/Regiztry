$(function(){ 							   

	// radiys box	
	$('.menu_nav ul li a').css({"border-radius": "5px 5px 0 0", "-moz-border-radius":"5px 5px 0 0", "-webkit-border-radius":"5px 5px 0 0"});
	
});	